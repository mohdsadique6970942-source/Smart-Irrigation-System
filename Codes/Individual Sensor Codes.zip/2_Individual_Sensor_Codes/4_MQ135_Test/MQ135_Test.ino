/*
  ==========================================
  TEST CODE 4 — MQ135 Air Quality Sensor
  ESP32 Smart Irrigation System
  Jamia Millia Islamia University
  ==========================================
  WIRING:
    MQ135 VCC → 5V
    MQ135 DO  → GPIO27   ← Digital output
    MQ135 GND → GND

  NOTE: Sensor needs 3 minutes warmup after power on.
        First readings will show POOR — this is normal.
        Adjust sensitivity using potentiometer on module.
  ==========================================
*/

#define MQ135_PIN     27
#define WARMUP_MS     180000   // 3 minutes

void setup() {
  Serial.begin(115200);
  pinMode(MQ135_PIN, INPUT);
  Serial.println("MQ135 Air Quality Test");
  Serial.println("Warming up for 3 minutes...");
}

void loop() {
  unsigned long elapsed = millis();

  if (elapsed < WARMUP_MS) {
    long remaining = (WARMUP_MS - elapsed) / 1000;
    Serial.print("Warming up... "); Serial.print(remaining); Serial.println(" seconds left");
    delay(5000);
    return;
  }

  int  state = digitalRead(MQ135_PIN);
  // HIGH = air is GOOD (below threshold set by potentiometer)
  // LOW  = air is POOR (above threshold)

  Serial.print("Digital State : "); Serial.println(state);
  Serial.print("Air Quality   : "); Serial.println(state == HIGH ? "GOOD" : "POOR — gases detected");
  Serial.println("-----------------------------");
  delay(1000);
}
