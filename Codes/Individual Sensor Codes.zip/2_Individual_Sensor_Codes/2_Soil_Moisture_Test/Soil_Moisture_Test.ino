/*
  ==========================================
  TEST CODE 2 — Soil Moisture Sensor (Analog)
  ESP32 Smart Irrigation System
  Jamia Millia Islamia University
  ==========================================
  WIRING:
    Sensor VCC → 3.3V
    Sensor AO  → GPIO26   ← AO pin (analog), NOT DO
    Sensor GND → GND

  CALIBRATION STEPS:
    1. Upload this code
    2. Open Serial Monitor at 115200
    3. Hold sensor in DRY AIR → note RAW ADC value → set as DRY_VAL
    4. Dip sensor in water    → note RAW ADC value → set as WET_VAL
    5. Update DRY_VAL and WET_VAL below
  ==========================================
*/

#define SOIL_PIN  26

// ── Update these after calibration ──
#define DRY_VAL   4095   // ADC value when completely dry
#define WET_VAL    800   // ADC value when fully in water

void setup() {
  Serial.begin(115200);
  Serial.println("Soil Moisture Sensor Test");
  Serial.println("DRY = sensor in air | WET = sensor in water");
  Serial.println("-----------------------------");
}

void loop() {
  int rawADC     = analogRead(SOIL_PIN);
  int soilPct    = map(rawADC, DRY_VAL, WET_VAL, 0, 100);
  soilPct        = constrain(soilPct, 0, 100);

  String status;
  if      (soilPct < 20) status = "VERY DRY";
  else if (soilPct < 30) status = "DRY";
  else if (soilPct < 60) status = "MOIST";
  else if (soilPct < 80) status = "WET";
  else                   status = "SATURATED";

  Serial.print("RAW ADC     : "); Serial.println(rawADC);
  Serial.print("Soil        : "); Serial.print(soilPct); Serial.println(" %");
  Serial.print("Status      : "); Serial.println(status);
  Serial.println("-----------------------------");
  delay(1000);
}
