/*
  ==========================================
  TEST CODE 3 — pH Sensor (Analog)
  ESP32 Smart Irrigation System
  Jamia Millia Islamia University
  ==========================================
  WIRING:
    pH Module VCC → 5V
    pH Module Po  → Voltage Divider → GPIO34
    pH Module GND → GND (common)

  VOLTAGE DIVIDER (REQUIRED):
    pH Po ──[ 10kΩ ]──┬── GPIO34
                      │
                    [20kΩ]
                      │
                     GND

  NOTE: pH probe must be in liquid for valid readings.
        Reading in air will show ~13-14 (floating voltage).
  ==========================================
*/

#define PH_PIN  34

void setup() {
  Serial.begin(115200);
  Serial.println("pH Sensor Test");
  Serial.println("Dip probe in liquid for valid readings");
  Serial.println("-----------------------------");
}

void loop() {
  int   rawADC  = analogRead(PH_PIN);
  float voltage = rawADC * (3.3 / 4095.0);
  float phValue = 7.0 + ((2.5 - voltage) / 0.18);
  phValue       = constrain(phValue, 0.0, 14.0);

  String status;
  if      (phValue < 5.5) status = "ACIDIC   — too low for plants";
  else if (phValue > 7.5) status = "ALKALINE — too high for plants";
  else                    status = "NORMAL   — good for plants";

  Serial.print("RAW ADC  : "); Serial.println(rawADC);
  Serial.print("Voltage  : "); Serial.print(voltage, 3); Serial.println(" V");
  Serial.print("pH Value : "); Serial.println(phValue, 2);
  Serial.print("Status   : "); Serial.println(status);
  Serial.println("-----------------------------");
  delay(1000);
}
