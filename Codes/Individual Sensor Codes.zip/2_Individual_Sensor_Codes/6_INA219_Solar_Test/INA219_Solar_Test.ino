/*
  ==========================================
  TEST CODE 6 — INA219 Solar Current Monitor
  ESP32 Smart Irrigation System
  Jamia Millia Islamia University
  ==========================================
  WIRING:
    INA219 VCC  → 3.3V
    INA219 GND  → GND
    INA219 SDA  → GPIO21
    INA219 SCL  → GPIO22
    INA219 VIN+ → Solar Panel (+)
    INA219 VIN- → Solar Panel (-)

  I2C ADDRESS: 0x40 (default)

  LIBRARY NEEDED:
    Arduino IDE → Manage Libraries → "Adafruit INA219" → Install
    Also install "Adafruit BusIO" if prompted

  NOTE: No external shunt resistor needed.
        INA219 has built-in 0.1Ω shunt resistor.
  ==========================================
*/

#include <Wire.h>
#include <Adafruit_INA219.h>

Adafruit_INA219 ina219;

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);

  if (!ina219.begin()) {
    Serial.println("ERROR: INA219 not found!");
    Serial.println("Check: SDA=GPIO21, SCL=GPIO22, VCC=3.3V");
    while (true);
  }

  Serial.println("INA219 Solar Monitor Test");
  Serial.println("-----------------------------");
}

void loop() {
  float voltage = ina219.getBusVoltage_V();
  float current = ina219.getCurrent_mA();
  float power   = ina219.getPower_mW();

  if (current < 0) current = 0;   // no negative current

  Serial.print("Solar Voltage : "); Serial.print(voltage, 3); Serial.println(" V");
  Serial.print("Solar Current : "); Serial.print(current, 2); Serial.println(" mA");
  Serial.print("Solar Power   : "); Serial.print(power / 1000.0, 4); Serial.println(" W");
  Serial.print("Panel Usage   : "); Serial.print((power / 20000.0) * 100.0, 1); Serial.println("% of 20W rated");
  Serial.println("-----------------------------");
  delay(1000);
}
