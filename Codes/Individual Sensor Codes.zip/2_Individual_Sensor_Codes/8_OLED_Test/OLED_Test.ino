/*
  ==========================================
  TEST CODE 8 — OLED Display SSD1306
  ESP32 Smart Irrigation System
  Jamia Millia Islamia University
  ==========================================
  WIRING:
    OLED VCC → 3.3V
    OLED GND → GND
    OLED SDA → GPIO21
    OLED SCL → GPIO22

  I2C ADDRESS: 0x3C (try 0x3D if blank)

  LIBRARIES NEEDED:
    Arduino IDE → Manage Libraries:
    1. "Adafruit SSD1306" → Install
    2. "Adafruit GFX Library" → Install
  ==========================================
*/

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH  128
#define SCREEN_HEIGHT  64

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("ERROR: OLED not found!");
    Serial.println("Try address 0x3D if 0x3C fails");
    while (true);
  }

  display.setTextColor(WHITE);
  Serial.println("OLED found and running!");
}

void loop() {
  // Page 1
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);   display.println("SMART IRRIGATION");
  display.setCursor(0, 12);  display.println("Jamia Millia Islamia");
  display.setTextSize(2);
  display.setCursor(0, 28);  display.println("OLED OK!");
  display.setTextSize(1);
  display.setCursor(0, 52);  display.println("SSD1306 128x64");
  display.display();
  delay(2000);

  // Page 2
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);   display.println("-- TEST VALUES ------");
  display.setCursor(0, 14);  display.print("Temp : 28.5 C");
  display.setCursor(0, 26);  display.print("Hum  : 62 %");
  display.setCursor(0, 38);  display.print("Soil : 45 %");
  display.setCursor(0, 50);  display.print("Pump : OFF");
  display.display();
  delay(2000);
}
