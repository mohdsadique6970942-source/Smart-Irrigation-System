/*
  ==========================================
  TEST CODE 5 — NPK Sensor (RS485 Modbus RTU)
  Model: ZTS-3002-TR-NPK-N01
  ESP32 Smart Irrigation System
  Jamia Millia Islamia University
  ==========================================
  WIRING:
    NPK brown  (VCC) → 12V supply (REQUIRED — min 4.5V)
    NPK black  (GND) → GND (common)
    NPK yellow (A+)  → RS485 Module A terminal
    NPK blue   (B-)  → RS485 Module B terminal

    RS485 Module RO  → GPIO16 (UART2 RX)
    RS485 Module DI  → GPIO17 (UART2 TX)
    RS485 Module RE  → GPIO5  (tie RE and DE together)
    RS485 Module DE  → GPIO5  (same pin)
    RS485 Module VCC → 5V
    RS485 Module GND → GND

  SETTINGS: Baud 4800, Address 0x01, Modbus RTU

  IF READING -1: Check 12V power to NPK sensor brown wire.
                 That is the most common cause.
  ==========================================
*/

#include <HardwareSerial.h>

#define RE_DE  5

HardwareSerial npkSerial(2);   // UART2

// Modbus RTU request frames — ZTS-3002-TR-NPK-N01
byte reqN[]     = {0x01, 0x03, 0x00, 0x00, 0x00, 0x01, 0x84, 0x0A};
byte reqP[]     = {0x01, 0x03, 0x00, 0x01, 0x00, 0x01, 0xD5, 0xCA};
byte reqK[]     = {0x01, 0x03, 0x00, 0x02, 0x00, 0x01, 0x25, 0xCA};
byte reqN_alt[] = {0x01, 0x03, 0x00, 0x1E, 0x00, 0x01, 0xE4, 0x0C};
byte reqP_alt[] = {0x01, 0x03, 0x00, 0x1F, 0x00, 0x01, 0xB5, 0xCC};
byte reqK_alt[] = {0x01, 0x03, 0x00, 0x20, 0x00, 0x01, 0x85, 0xC0};
byte resp[7];

int readNPK(byte* req) {
  while (npkSerial.available()) npkSerial.read();  // clear buffer
  digitalWrite(RE_DE, HIGH);  // transmit mode
  delay(10);
  npkSerial.write(req, 8);
  npkSerial.flush();
  digitalWrite(RE_DE, LOW);   // receive mode
  delay(300);

  if (npkSerial.available() >= 7) {
    for (int i = 0; i < 7; i++) resp[i] = npkSerial.read();
    // Validate response header
    if (resp[0] == 0x01 && resp[1] == 0x03) {
      return (resp[3] << 8) | resp[4];   // 16-bit value
    }
  }
  return -1;
}

void setup() {
  Serial.begin(115200);
  pinMode(RE_DE, OUTPUT);
  digitalWrite(RE_DE, LOW);
  npkSerial.begin(4800, SERIAL_8N1, 16, 17);
  Serial.println("NPK Sensor Test — ZTS-3002-TR-NPK-N01");
  Serial.println("Baud: 4800 | Address: 0x01 | RS485 Modbus RTU");
  Serial.println("If -1: check 12V power on brown wire!");
  Serial.println("-----------------------------");
  delay(1000);
}

void loop() {
  int N = readNPK(reqN); delay(150);
  if (N == -1) { N = readNPK(reqN_alt); delay(150); }

  int P = readNPK(reqP); delay(150);
  if (P == -1) { P = readNPK(reqP_alt); delay(150); }

  int K = readNPK(reqK); delay(150);
  if (K == -1) { K = readNPK(reqK_alt); delay(150); }

  Serial.print("Nitrogen (N) : ");
  N == -1 ? Serial.println("No response — check wiring & 12V") : (Serial.print(N), Serial.println(" mg/kg"));

  Serial.print("Phosphorus(P): ");
  P == -1 ? Serial.println("No response") : (Serial.print(P), Serial.println(" mg/kg"));

  Serial.print("Potassium (K): ");
  K == -1 ? Serial.println("No response") : (Serial.print(K), Serial.println(" mg/kg"));

  Serial.println("-----------------------------");
  delay(2000);
}
