/*
  ==========================================
  TEST CODE 1 — DHT11 Temperature & Humidity
  ESP32 Smart Irrigation System
  Jamia Millia Islamia University
  ==========================================
  WIRING:
    DHT11 VCC  → 3.3V
    DHT11 DATA → GPIO4 + 10kΩ resistor to 3.3V
    DHT11 GND  → GND

  LIBRARY NEEDED:
    Arduino IDE → Manage Libraries → "DHT sensor library" by Adafruit → Install
  ==========================================
*/

#include <DHT.h>

#define DHTPIN   4
#define DHTTYPE  DHT11

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);
  dht.begin();
  Serial.println("DHT11 Test Starting...");
}

void loop() {
  float temp = dht.readTemperature();
  float hum  = dht.readHumidity();

  if (isnan(temp) || isnan(hum)) {
    Serial.println("ERROR: DHT11 not responding!");
    Serial.println("Check: 10kΩ resistor on DATA pin to 3.3V?");
  } else {
    Serial.print("Temperature : "); Serial.print(temp); Serial.println(" °C");
    Serial.print("Humidity    : "); Serial.print(hum);  Serial.println(" %");
  }

  Serial.println("-----------------------------");
  delay(2000);
}
