/*
  ==========================================
  TEST CODE 7 — Relay + Water Pump Test
  ESP32 Smart Irrigation System
  Jamia Millia Islamia University
  ==========================================
  WIRING:
    Relay Module VCC → 5V
    Relay Module GND → GND
    Relay Module IN  → GPIO13

    Relay COM        → 12V Supply (+) via Switch
    Relay NO         → Pump positive (+)
    12V Supply (-)   → Pump negative (-)

  PUMP CIRCUIT:
    12V (+) → Switch → Relay COM → Relay NO → Pump (+)
    12V (-) ──────────────────────────────── Pump (-)

  NOTE: Use relay MODULE (with optocoupler on board).
        LOW = Relay ON = Pump runs
        HIGH = Relay OFF = Pump stops
  ==========================================
*/

#define RELAY_PIN  13

void setup() {
  Serial.begin(115200);
  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, HIGH);  // pump OFF at start
  Serial.println("Relay + Pump Test");
  Serial.println("Pump: ON 3 seconds → OFF 3 seconds → repeat");
  Serial.println("-----------------------------");
}

void loop() {
  // Pump ON
  digitalWrite(RELAY_PIN, LOW);
  Serial.println("PUMP: ON");
  delay(3000);

  // Pump OFF
  digitalWrite(RELAY_PIN, HIGH);
  Serial.println("PUMP: OFF");
  delay(3000);
}
